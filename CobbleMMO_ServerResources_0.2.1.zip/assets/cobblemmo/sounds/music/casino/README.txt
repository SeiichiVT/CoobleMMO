Hier spaeter casino_theme.ogg (Ogg Vorbis) einfuegen.
Pfad in der ZIP: assets/cobblemmo/sounds/music/casino/casino_theme.ogg
Soundevent fuer Meret: cobblemmo:music.casino_theme
sounds.json ist bereits vorbereitet; stream ist true.
Dieses Pack enthaelt absichtlich keine Audiodateien.
Nach dem Einfuegen die ZIP speichern und den SHA1 fuer server.properties neu berechnen.
